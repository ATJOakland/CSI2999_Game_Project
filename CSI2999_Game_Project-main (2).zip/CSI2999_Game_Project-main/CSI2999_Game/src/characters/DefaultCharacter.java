package characters;

public class DefaultCharacter {
	// Default variables for ALL types of characters (player and enemies and even NPCs)
	public int posX, posY;
	public int characterSpeed;
	
	/*
	 * Idk if we're doing character animations/player animations but it would be done in here and in Player.
	 * Here's a vid of how it would be done:
	 * https://www.youtube.com/watch?v=wT9uNGzMEM4&list=PL_QPQmz5C6WUF-pOQDsbsKbaBZqXj4qSq&index=3
	 */
}
